--- © Creditos da pagina postadora: DropMTA

--- © Discord DropMTA: https://discord.gg/GZ8DzrmxUV

--- Acesse nosso site de mods: https://www.dropmta.com.br/

txd = engineLoadTXD( '10.txd' )
engineImportTXD( txd, 37 )
dff = engineLoadDFF('10.dff', 37)
engineReplaceModel( dff, 37 )

--- © Creditos da pagina postadora: DropMTA

--- © Discord DropMTA: https://discord.gg/GZ8DzrmxUV

--- Acesse nosso site de mods: https://www.dropmta.com.br/