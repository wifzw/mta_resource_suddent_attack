﻿function setNewGameType()
setGameType("Suddent Attack Battle PVP")
end
addEventHandler("onResourceStart", getRootElement(), setNewGameType)
