pickupD = {872.685, -1341.608, 13.547} --Local para colocar o pickup do painel

range = 25 -- Alcance dos jogadores perto do painel

playerOne = {-1390.1750488281,-274.88638305664,27.888874053955} -- Teleporte do jogador 1.
playerTwo = {-1355.8101806641,-329.04150390625,27.61522102356} -- Teleporte do jogador 2

CompletionDuel = {-1416.1081542969,-301.01443481445,14.141115188599} -- Teleporte depois do fim do duelo

duelTimeLimit = 10 -- Tempo para o duelo começar

weapData = { -- Tipos de id/numero/slot
    {"No soco",0,0},
    {"Com bastão",5,1},
    {"Molotov",18,8},
    {"Pistola silenciosa",23,2},
    {"Serra eletrica",26,3},
    {"Uzi",28,4},
    {"MP5",29,4},
    {"АК-47",30,5},
    {"M4",31,5},
    {"Tec9",32,4},
    {"Rifle",33,6},
    {"RPG",36,7},
    {"Lança-Chamas",37,7},
    {"Minigun",38,7},
}