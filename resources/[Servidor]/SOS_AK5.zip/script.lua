--- © Creditos da pagina postadora: DropMTA

--- © Discord DropMTA: https://discord.gg/GZ8DzrmxUV

--- Acesse nosso site de mods: https://www.dropmta.com.br/

addEventHandler('onClientResourceStart',resourceRoot,function () 
txd = engineLoadTXD( 'ak.txd' ) 
engineImportTXD( txd, 355 ) 
dff = engineLoadDFF('ak.dff', 355) 
engineReplaceModel( dff, 355)
end)

--- © Creditos da pagina postadora: DropMTA

--- © Discord DropMTA: https://discord.gg/GZ8DzrmxUV

--- Acesse nosso site de mods: https://www.dropmta.com.br/