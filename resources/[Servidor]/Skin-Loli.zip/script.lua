--- © Creditos da pagina postadora: DropMTA

--- © Discord DropMTA: https://discord.gg/GZ8DzrmxUV

--- Acesse nosso site de mods: https://www.dropmta.com.br/

txd = engineLoadTXD( 'Loli.txd' )
engineImportTXD( txd, 53 )
dff = engineLoadDFF('Loli.dff', 53)
engineReplaceModel( dff, 53 )

--- © Creditos da pagina postadora: DropMTA

--- © Discord DropMTA: https://discord.gg/GZ8DzrmxUV

--- Acesse nosso site de mods: https://www.dropmta.com.br/