--- © Creditos da pagina postadora: DropMTA

--- © Discord DropMTA: https://discord.gg/GZ8DzrmxUV

--- Acesse nosso site de mods: https://www.dropmta.com.br/

addEventHandler('onClientResourceStart',resourceRoot,function () 
txd = engineLoadTXD( 'm4.txd' ) 
engineImportTXD( txd, 356 ) 
dff = engineLoadDFF('m4.dff', 356) 
engineReplaceModel( dff, 356 )
end)

--- © Creditos da pagina postadora: DropMTA

--- © Discord DropMTA: https://discord.gg/GZ8DzrmxUV

--- Acesse nosso site de mods: https://www.dropmta.com.br/