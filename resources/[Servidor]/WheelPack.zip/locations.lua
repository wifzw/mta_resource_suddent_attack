--------------------------------
-----------By: C4N3L4-----------
--------------------------------
function onClientResourceStart()
	createWheels ( -1634.4295654297, -283.50799560547, 14.14396572113 )
end
addEventHandler ( "onClientResourceStart", resourceRoot, onClientResourceStart )

function createWheels(x, y, z)
	createObject ( 1085, x, y, z )
	createObject ( 1096, x, y, z )
	createObject ( 1097, x, y, z )
	createObject ( 1098, x, y, z )
	createObject ( 1078, x, y, z )
	createObject ( 1076, x, y, z )
	createObject ( 1084, x, y, z )
	createObject ( 1079, x, y, z )
	createObject ( 1074, x, y, z )
	createObject ( 1081, x, y, z )

	createObject ( 1000, x, y, z )
	createObject ( 1001, x, y, z )
	createObject ( 1002, x, y, z )
	createObject ( 1003, x, y, z )



	createObject ( 1025, x, y, z )
	createObject ( 1073, x, y, z )
	createObject ( 1075, x, y, z )
	createObject ( 1077, x, y, z )
	createObject ( 1080, x, y, z )
	createObject ( 1082, x, y, z )
	createObject ( 1083, x, y, z )
end

-- Sitemiz : https://sparrow-mta.blogspot.com/

-- Facebook : https://facebook.com/sparrowgta/
-- İnstagram : https://instagram.com/sparrowmta/
-- YouTube : https://youtube.com/c/SparroWMTA/

-- Discord : https://discord.gg/DzgEcvy
