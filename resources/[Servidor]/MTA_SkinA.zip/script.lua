--- © Creditos da pagina postadora: DropMTA

--- © Discord DropMTA: https://discord.gg/GZ8DzrmxUV

--- Acesse nosso site de mods: https://www.dropmta.com.br/

txd = engineLoadTXD( 'Ale.txd' )
engineImportTXD( txd, 13 )
dff = engineLoadDFF('Ale.dff', 13)
engineReplaceModel( dff, 13 )

--- © Creditos da pagina postadora: DropMTA

--- © Discord DropMTA: https://discord.gg/GZ8DzrmxUV

--- Acesse nosso site de mods: https://www.dropmta.com.br/