--#########CREDITOS: MODS MTA OFICIAL - SRGRINGO MTA
function addNotification(player,text,type)
	triggerClientEvent(player,"infobox",player,text,type)
end