--- © Creditos da pagina postadora: DropMTA

--- © Discord DropMTA: https://discord.gg/GZ8DzrmxUV

--- Acesse nosso site de mods: https://www.dropmta.com.br/

txd = engineLoadTXD( 'F.txd' )
engineImportTXD( txd, 69 )
dff = engineLoadDFF('F.dff', 69)
engineReplaceModel( dff, 69 )

--- © Creditos da pagina postadora: DropMTA

--- © Discord DropMTA: https://discord.gg/GZ8DzrmxUV

--- Acesse nosso site de mods: https://www.dropmta.com.br/