DEBUGMODE = true

MTAVER = 1.2
HVER = "2.0 beta RC2"
HREV = 0xA1
HMREV = 0x89