setting = {
    usedKey = "b",
    usedCommand = "hedit",
    language = "english",
    template = "default",
    commode = "splitted",
    version = tostring ( HREV ),
    minVersion = tostring ( HMREV ),
    notifyUpdate = "false",
    notifyUpgrade = "false",
    mtaVersion = 0,
	lockVehicleWhenEditing = true
}