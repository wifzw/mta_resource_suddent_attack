function checkForUpdate ( )
end